const items = document.getElementsByClassName("button_z")
for (let i of items) {
  i.addEventListener("click", function() {
      window.location.href = "../drawing tool js/Drawing tool.html";
    });
for (let i of items) {i.addEventListener("click", function() {
  window.location.href = "../drawing tool js/Drawing tool.html";
});

}
}
const item = document.getElementsByClassName("button_nav")
for (let i of item) {
  i.addEventListener("click", function() {
      window.location.href = "./test.html";
    });
for (let i of item) {i.addEventListener("click", function() {
  window.location.href = "./test.html";
});
}
}

